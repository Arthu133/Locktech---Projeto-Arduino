package com.example.locktech

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
