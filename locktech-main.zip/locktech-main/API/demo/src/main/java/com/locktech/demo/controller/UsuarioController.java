package com.locktech.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.locktech.demo.entidades.Produto;
import com.locktech.demo.entidades.Usuario;
import com.locktech.demo.service.ProdutoService;
import com.locktech.demo.service.UsuarioService;

@RestController
@RequestMapping("/teste")
public class UsuarioController {
	
private final UsuarioService usuarioService;
	
	@Autowired
	public UsuarioController(UsuarioService usuarioService) {
		this.usuarioService = usuarioService;
	}
	
	@GetMapping("/listar")
	public List<Usuario> listarUsuario() {
		return usuarioService.listarUsuario();
	}
	
	
	@PostMapping
	public ResponseEntity salvarUsuario(@RequestBody Usuario usuario) {
		usuarioService.salvarUsuario(usuario);
		try {
            return new ResponseEntity<>("Produto salvo com sucesso", HttpStatus.OK);

		}catch(Exception e) {
            return new ResponseEntity<>("Falha ao salvar o produto: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);

		}

	}
	

}
