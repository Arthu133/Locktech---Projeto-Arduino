package com.locktech.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.locktech.demo.entidades.Produto;

public interface ProdutoRepository extends CrudRepository<Produto, Integer> {

	@Query("SELECT p FROM Produto p WHERE p.quantidade <= 15")
	List<Produto> verificaEstoqueProdutos();

	@Query("SELECT p FROM Produto p WHERE p.dataValidade <= :dataAtual")
	List<Produto> verificarDataValidade(@Param("dataAtual") String dataAtual);

	@Query("SELECT p FROM Produto p WHERE p.dataValidade< :dataAtual")
	List<Produto> verificarValidadeExpirada(@Param("dataAtual") String dataAtual);

	@Query("SELECT p FROM Produto p WHERE FUNCTION('DATE', p.dataDeRegistro) = CURRENT_DATE")
	List<Produto> novoLoteProduto();

	@Query("SELECT p FROM Produto p WHERE p.categoria = :categoria")
	List<Produto> filterCategoria(@Param("categoria") String categoria);
	
	@Query("SELECT DISTINCT p.categoria FROM Produto p")
	List<String> getCategorias();
	

}