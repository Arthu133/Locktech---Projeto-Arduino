package com.locktech.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.locktch.demo.util.Util;
import com.locktech.demo.entidades.Produto;
import com.locktech.demo.entidades.Usuario;
import com.locktech.demo.repository.ProdutoRepository;

@Service
public class ProdutoService {
	
	private final ProdutoRepository produtoRepository;
	
	@Autowired
	public ProdutoService(ProdutoRepository produtoRepository) {
		this.produtoRepository = produtoRepository;
	}
	
	public List<Produto> listarProdutos() {
		return (List<Produto>) produtoRepository.findAll();
	}
	
	public ResponseEntity<Produto> salvarProduto(@RequestBody Produto produto) {
		Produto novoProduto = produtoRepository.save(produto);
		return new ResponseEntity<>(novoProduto, HttpStatus.CREATED);
	}
	
	public void deletarProduto(Integer id) {
		produtoRepository.deleteById(id);
	}

	public List<Produto> verificarEstoqueProdutos() {		
		return (List<Produto>) produtoRepository.verificaEstoqueProdutos(); 
	}

	public List<Produto> verificarDataValidade() {
		String dataAtual = new Util().getData();
		return  (List<Produto>) produtoRepository.verificarDataValidade(dataAtual);
	}

	public List<Produto> verificarValidadeExpirada() {
		String dataAtual = new Util().getData();
		return (List<Produto>) produtoRepository.verificarValidadeExpirada(dataAtual);
	}

	public List<Produto> novoLoteProduto() {
		return (List<Produto>) produtoRepository.novoLoteProduto();
	}
	
	public List<Produto> filterCategoria(String categoria) {
		return (List<Produto>) produtoRepository.filterCategoria(categoria);
	}

	public List<String> getCategorias() {
	
		return (List<String>) produtoRepository.getCategorias();
		
	}

	
	
	
	
	
}
