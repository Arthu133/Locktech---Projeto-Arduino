package com.locktech.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.locktech.demo.entidades.Produto;
import com.locktech.demo.entidades.Usuario;
import com.locktech.demo.service.ProdutoService;

@RestController
@RequestMapping("/api")
public class ProdutoController implements IntefacePadrao{
	
	private final ProdutoService produtoService;
	
	@Autowired
	public ProdutoController(ProdutoService produtoService) {
		this.produtoService = produtoService;
	}
	
	@GetMapping("/listar2")
	public List<Produto> listarProduto() {
		return produtoService.listarProdutos();
	}
	
	@PostMapping
	public ResponseEntity salvarProduto(@RequestBody Produto produto) {
		produtoService.salvarProduto(produto);
		try {
            return new ResponseEntity<>("Produto salvo com sucesso", HttpStatus.OK);

		}catch(Exception e) {
            return new ResponseEntity<>("Falha ao salvar o produto: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);

		}

	}
		
	@DeleteMapping("/{id}")
	public void deletarPessoa(@PathVariable Integer id) {
		produtoService.deletarProduto(id);
	}

	
	@GetMapping("/verificarEstoque")
	@Override
	public List<Produto> verificaEstoqueProdutos() {
		return produtoService.verificarEstoqueProdutos();
		
	} 

	@GetMapping("/verificarDataValidade")
	@Override
	public List<Produto> verificarDataValidade() {
		
		return produtoService.verificarDataValidade();
	}
	
	@GetMapping("/existeProdutoExpirado")
	@Override
	public List<Produto> validadeExpirada() {
		
		return produtoService.verificarValidadeExpirada();
	}
	
	@GetMapping("/filterCategoria/{categoria}")
	public List<Produto> filterCategoria(@PathVariable String categoria) {
		return (List<Produto>) produtoService.filterCategoria(categoria);
	}
	
	
	@GetMapping("/existeNovoLote")
	@Override
	public List<Produto> novoLoteProduto() {
		return produtoService.novoLoteProduto();
	}
	
	
	@GetMapping("/getCategorias")
	public List<String> getCategorias() {
		return produtoService.getCategorias();
	}

	@Override
	public String controleDeAcesso() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Produto> filterCategoria() {
		// TODO Auto-generated method stub
		return null;
	}

}
