package com.locktech.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.locktech.demo.entidades.Produto;
import com.locktech.demo.entidades.Usuario;

public interface UsuarioRepository extends CrudRepository<Usuario, Integer>{

}
