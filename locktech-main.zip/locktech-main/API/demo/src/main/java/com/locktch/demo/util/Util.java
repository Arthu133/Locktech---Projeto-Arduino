package com.locktch.demo.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Util {

	public String getData() {
		
		 LocalDate dataAtual = LocalDate.now();

	        // Formate a data conforme necessário (opcional)
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	        String dataFormatada = dataAtual.format(formatter);

	        String retorno = "Data Atual: " + dataFormatada;
//	        System.out.println("Data Atual: " + dataFormatada);
			return dataFormatada;
	}
}
