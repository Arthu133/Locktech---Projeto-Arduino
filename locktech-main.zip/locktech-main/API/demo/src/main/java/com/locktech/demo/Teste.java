package com.locktech.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Teste {
	
	@GetMapping("/teste")
	public String getExemplo() {
		return "Resposta da API, LOCKTECH MOTHERFUCKERS LAST GO";
	}

}
