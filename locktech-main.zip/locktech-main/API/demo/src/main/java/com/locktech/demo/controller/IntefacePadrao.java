package com.locktech.demo.controller;

import java.util.List;

import com.locktech.demo.entidades.Produto;

public interface IntefacePadrao {
		
	List<Produto> verificaEstoqueProdutos();
	
	List<Produto> verificarDataValidade();
	
	List<Produto> validadeExpirada();
	
	List<Produto> novoLoteProduto();
	
	List<Produto> filterCategoria();
	
	String controleDeAcesso();
	
}
