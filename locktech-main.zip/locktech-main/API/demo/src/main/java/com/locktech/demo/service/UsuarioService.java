package com.locktech.demo.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.locktch.demo.util.Util;
import com.locktech.demo.entidades.Produto;
import com.locktech.demo.entidades.Usuario;
import com.locktech.demo.entidades.Usuario;
import com.locktech.demo.repository.UsuarioRepository;

@Service
public class UsuarioService {
	
private final UsuarioRepository usuarioRepository;
	
	@Autowired
	public UsuarioService(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository;
	}

	public void salvarUsuario(Usuario usuario) {
	
		usuarioRepository.save(usuario);
	}

	public List<Usuario> listarUsuario() {
		return (List<Usuario>) usuarioRepository.findAll();
	}
	
	

	
	

	
	

}
