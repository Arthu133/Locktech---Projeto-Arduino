

import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:locktech/entidades/entidades.dart';
import 'package:locktech/paginas/produto_api.dart';
import 'package:http/http.dart' as http;


class ProductProvider with ChangeNotifier {

  Timer? _timerProdutos;
  Timer? _timerLivros;
  Timer? _timerRoupas;
  Timer? _timerAlimentos;

  
  List<Produto> _listaDeProdutos = [];
  List<Produto> _listaCategoriaLivros = [];
  List<Produto> _listaCategoriaRoupas = [];
  List<Produto> _listaCategoriaAlimentos = [];

  // Getter para acessar as listas de fora da classe
  List<Produto> get listaDeProdutos => _listaDeProdutos;
  List<Produto> get listaCategoriaLivros => _listaCategoriaLivros;
  List<Produto> get listaCategoriaRoupas => _listaCategoriaRoupas;
  List<Produto> get listaCategoriaAlimentos => _listaCategoriaAlimentos;

  List<Produto> _userCart = [];

  List<Produto> get userCart => _userCart;

  void addItemCart(Produto produto) {
    _userCart.add(produto);
  }

  void removeItemFromCart(Produto produto) {
    _userCart.remove(produto);
  }


   Future<List<dynamic>> buscarProdutos(String query) async {
    final response = await http.get(Uri.parse('http://192.168.122.1:8082/api/buscarProduto?query=$query'));
        
                   //=> Produto.fromJson(json)).toList();

    if (response.statusCode == 200) {
       final List<dynamic> produtosJson = json.decode(response.body);
  return produtosJson;
    } else {
      throw Exception('Erro ao buscar produtos');
    }
  }



  Future<void> openESP() async {

    print("entrou aqui");

    try {
      final response = await http.get(Uri.parse("http://192.168.0.50/1"));

      if (response.statusCode == 200) {
       

      } else {
        print('Erro na solicitação. Código de status: ${response.statusCode}');
      }
    } catch (e) {
      print('Erro durante a solicitação: $e');
    }

    ProdutoApi funcaoESP = ProdutoApi(apiUrl: "http://192.168.0.50/1", onProdutoFetched: testESP);

  }

  Future<void> closeESP() async {

    print("entrou aqui");

    try {
      final response = await http.get(Uri.parse("http://192.168.0.50/0"));

      if (response.statusCode == 200) {
       

      } else {
        print('Erro na solicitação. Código de status: ${response.statusCode}');
      }
    } catch (e) {
      print('Erro durante a solicitação: $e');
    }

    ProdutoApi funcaoESP = ProdutoApi(apiUrl: "http://192.168.0.50/1", onProdutoFetched: testESP);

  }

  void testESP(List<Produto> produtos) {
    _listaCategoriaLivros = produtos;
  }


  ProductProvider() {
  _startPollingLivros();
  _startPollingAlimentos();
  _startPollingRoupas();
  }

  void getLivros(List<Produto> produtos) {
    _listaCategoriaLivros = produtos;
    notifyListeners();
  }

  void getAlimentos(List<Produto> produtos) {
   
    _listaCategoriaAlimentos = produtos;
    notifyListeners();

  }

 void getRoupas(List<Produto> produtos) {
      _listaCategoriaRoupas = produtos;
      notifyListeners();
  }

  void _startPollingRoupas() {
    _timerProdutos = Timer.periodic(Duration(seconds: 10), (timer) {
      ProdutoApi roupasAPI = ProdutoApi(
        apiUrl: "http://192.168.122.1:8082/api/filterCategoria/Roupas",
        onProdutoFetched: getRoupas,
      );
      roupasAPI.fetchData();
    });
  }

  void _startPollingLivros() {
    _timerProdutos = Timer.periodic(Duration(seconds: 10), (timer) {
      ProdutoApi livrosAPI = ProdutoApi(
        apiUrl: "http://192.168.122.1:8082/api/filterCategoria/Livros",
        onProdutoFetched: getLivros,
      );
      livrosAPI.fetchData();
      //print("Polling livros");
    });
  }

   void _startPollingAlimentos() {
    _timerProdutos = Timer.periodic(Duration(seconds: 10), (timer) {
      ProdutoApi alimentosAPI = ProdutoApi(
        apiUrl: "http://192.168.122.1:8082/api/filterCategoria/Alimentos",
        onProdutoFetched: getAlimentos,
      );
      alimentosAPI.fetchData();
      print("Polling Alimentos");

    });

     

  }

  
}