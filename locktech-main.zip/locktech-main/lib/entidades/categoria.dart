import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class Categoria {
  final String nome;
  final int quantidade;
  final Color cor;

  Categoria(this.nome, this.quantidade, this.cor);
}

class DynamicChartPage extends StatefulWidget {
  @override
  _DynamicChartPageState createState() => _DynamicChartPageState();
}

class _DynamicChartPageState extends State<DynamicChartPage> {
  List<Categoria> categorias = [];

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    // Obter os dados da sua fonte (por exemplo, API)
    // Para este exemplo, vamos usar valores fictícios
    setState(() {
      categorias = [
        Categoria("Alimentos", 10, Colors.red),
        Categoria("Livros", 5, Color.fromARGB(255, 0, 85, 212)),
        Categoria("Roupas", 8, Color.fromARGB(255, 10, 221, 73)),
        // ... outras categorias
      ];
    });
  }

  List<PieChartSectionData> getSections() {
    return categorias.map((categoria) {
      return PieChartSectionData(
        value: categoria.quantidade.toDouble(),
        color: categoria.cor,
      );
    }).toList();
  }
  
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }

 
}