class Produto {
  final int id;
  final String nome;
  final int quantidade;
  final String imagem;
  final String descricao;
  final String categoria;
  final String quantidadeInicial;
  final String dataValidade;
  final String dataDeRegistro;

  // Produto( this.id, this.nome, this.quantidade, this.descricao, this.categoria, this.quantidadeInicial, this.dataValidade, this.dataDeRegistro);

  Produto(
    {
    required this.id,
    required this.nome,
    required this.quantidade,
    required this.imagem,
    required this.descricao,
    required this.categoria,
    required this.quantidadeInicial,
    required this.dataValidade,
    required this.dataDeRegistro,
  });


 factory Produto.fromJson(Map<String, dynamic> json) {
    return Produto(
      id: json['id'],
      nome: json['nome'],
      quantidade: json['quantidade'],
      imagem: json['imagem'],
      descricao: json['descricao'],
      categoria: json['categoria'],
      quantidadeInicial: json['quantidadeInicial'],
      dataValidade: json['dataValidade'],
      dataDeRegistro: json['dataDeRegistro'],
    );
  }


  





}
