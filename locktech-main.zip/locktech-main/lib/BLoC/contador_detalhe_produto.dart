import 'dart:async';

enum CounterEvent { increment, decrement }

class CounterBloc {
  int _count = 0;

  // StreamControllers
  // StateController, serve para mostrar-mos na UI, o valor do produto armazenado
  final _counterStateController = StreamController<int>.broadcast();

  //EventController, serve para atribuirmos operacoes a UI. Ou seja,
  //Quero incrementar e decrementar o valor da UI. O EventController faz isso.
  final _counterEventController = StreamController<CounterEvent>();

  // Output (Stream)
  Stream<int> get counterStream => _counterStateController.stream;

  // Input (Sink)
  Sink<CounterEvent> get counterEventSink => _counterEventController.sink;

  CounterBloc() {
    // Sempre que um evento é adicionado ao _counterEventController, 
    // nós mapeamos esse evento para um novo estado e passamos para o _counterStateController.
    _counterEventController.stream.listen(_mapEventToState);
  }

  void _mapEventToState(CounterEvent event) {
    if (event == CounterEvent.increment) {
      _count++;
    } else {
      _count--;
    }

    _counterStateController.sink.add(_count);
  }

  void dispose() {
    _counterStateController.close();
    _counterEventController.close();
  }
}

enum TamanhoProduto {nenhum ,pequeno, medio, grande}

class BlocoTamanhoProduto {

  TamanhoProduto _tamanhoSelecionado = TamanhoProduto.nenhum;

  //StreamController
  final _tamanhoStateController = StreamController<TamanhoProduto>.broadcast();


  //Output(Stream)
  Stream<TamanhoProduto> get tamanhoStream => _tamanhoStateController.stream;

  //Input(Sink)
  Sink<TamanhoProduto> get tamanhoEventoSink => _tamanhoStateController.sink;

  void dispose() {
    _tamanhoStateController.close();
  }


}



class SizeBloc {
  ProductSize _selectedSize = ProductSize.none;

  // StreamController
  final _sizeStateController = StreamController<ProductSize>.broadcast();

  // Output (Stream)
  Stream<ProductSize> get sizeStream => _sizeStateController.stream;

  // Input (Sink)
  Sink<ProductSize> get sizeEventSink => _sizeStateController.sink;

  void dispose() {
    _sizeStateController.close();
  }
}

enum ProductSize { none, small, medium, large }


