import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:locktech/entidades/entidades.dart';
import 'package:locktech/paginas/TelaInicial.dart';
import 'package:locktech/paginas/adicionar_produto.dart';
import 'package:locktech/paginas/carrinho_compra.dart';
import 'package:locktech/paginas/categoria_produto.dart';
import 'package:locktech/paginas/detalhe_produto.dart';
import 'package:locktech/paginas/pesquisar_teste.dart';
import 'package:locktech/paginas/retirar_produto.dart';
import 'package:locktech/paginas/stream_teste.dart';
import 'package:locktech/provider/provider.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => ProductProvider(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        //  "/" : (context) => TelaBuscaProdutos(),
        '/': (context) => TelaInicial(),
        // '/': (context) => PaginaInicial(),
        // PaginaDestino  = Inserir Produtos
        '/pagina_destino': (context) => PaginaAdicionarProduto(),
        '/pagina_destino02': (context) => PaginaDestino02(),
        '/carrinho_compra': (context) => CarrinhoCompra(),

        //'/pagina_destino03': (context) => PaginaDestino03(),
        '/categoria_produto': (context) {
          final String categoria =
              ModalRoute.of(context)!.settings.arguments as String;
          return CategoriaProdutoPage(categoria: categoria);
        },
        '/detalhe_produto': (context) {
          final Produto produto =
              ModalRoute.of(context)!.settings.arguments as Produto;
          return DetalheProdutoPage(produtos: produto);
        },
      },
    );
  }
}

// class Product {
//   final String nome;
//   final int quantidade;

//   Product(this.nome, this.quantidade);

//   factory Product.fromJson(Map<String, dynamic> json) {
//     return Product(
//       json['nome'] as String,
//       json['quantidade'] as int,
//     );
//   }

// }

class PaginaInicial extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('TI V - Desenvolvimento'),
          centerTitle: true,
        ),
        body: ListView(
          children: [
            SmallSpaceContainer(),
            Container(
              child: LogoCircular(),
            ),
            MediumSpaceContainer(),
            Container(
              child: CircularIconButtonProductIN(),
            ),
            MediumSpaceContainer(),
            Container(
              child: CircularIconButtonProductOUT(),
            ),
          ],
        ));
  }
}

class TinySpaceContainer extends StatelessWidget {
  const TinySpaceContainer({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 25,
      width: 25,
    );
  }
}

class SmallSpaceContainer extends StatelessWidget {
  const SmallSpaceContainer({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      width: 50,
    );
  }
}

class MediumSpaceContainer extends StatelessWidget {
  const MediumSpaceContainer({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      width: 100,
    );
  }
}

// class PaginaDestino02 extends StatelessWidget {
//   //const PaginaDestino02({super.key});
//   final String apiUrl = 'http://192.168.122.1:8082/api/listar2'; // Substitua pela URL correta

//   @override

//    List<Product> listaDeProdutos = [
//   Product( "Produto 1", 10),
//   Product( "Produto 2",  19),
//   Product( "Produto 3",  5),
// ];

//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text('Lista Produtos'),),
//       body: ListView(
//         children: [
//           Container(
//             height: 50,
//             width: 50,

//           ),
//           LogoCircular(),
//           Container(
//             height: 50,
//             width: 50,

//           ),
//                     PesquisaComIconeWidget(),

//           Container(
//             height: 50,
//             width: 50,
//           ),

//           Text('Produtos Adicionados:'),
//           Column(

//           children: listaDeProdutos.map((product) {
//             return ListTile(
//               title: Text(product.name),
//               subtitle: Text('Quantidade: ${product.quantity}'),
//               trailing: ElevatedButton(
//                 onPressed: () {
//                   print('Botão de adicionar ao carinho');
//                 },
//                 child: Text('ADD'),
//               ),
//             );
//           }).toList(),
//         ),

//         ElevatedButton(onPressed: () {
//           Navigator.pushNamed(context, '/pagina_destino03');
//         }, child: Text('GO'))

//         ],
//       ),
//     );
//   }
// }

class ListaPersonalizadaItens extends StatelessWidget {
  final List<Produto> lista;

  ListaPersonalizadaItens({required this.lista});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text('Morango'),
        SizedBox(
          height: 20,
        ),
        Text('Abacaxi'),
        SizedBox(
          height: 20,
        ),
        Text('Uva'),
        SizedBox(
          height: 20,
        ),
        Text('Melancia'),
        SizedBox(
          height: 20,
        ),
        Text('Melão'),
        SizedBox(
          height: 20,
        ),
        Text('Mixirica'),
        SizedBox(
          height: 20,
        ),
        ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(context, '/');
            },
            child: Icon(Icons.check))
      ],
    );
  }
}

// class PaginaDestino03 extends StatelessWidget {
//   //const PaginaDestino03({super.key});
//   List<Product> listaDeProdutos = [
//     Product("Produto 1", 10),
//     Product("Produto 2", 19),
//     Product("Produto 3", 5),
//   ];

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text('CheckOut Page')),
//       body: ListView(
//         children: [
//           SmallSpaceContainer(),

//           LogoCircular(),

//           SmallSpaceContainer(),

//           ListaPersonalizadaItens(lista: listaDeProdutos)
//         ],
//       ),
//     );
//   }
// }

class LogoCircular extends StatelessWidget {
  //const LogoCircular({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 200,
      height: 200,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.blue,
      ),
      child: Center(
          child: Text(
        'LockTech',
        style: TextStyle(color: Colors.white, fontSize: 20),
      )),
    );
  }
}

class CircularTextContainer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 200, // Defina o tamanho do container circular
      height: 200,
      decoration: BoxDecoration(
        shape: BoxShape.circle, // Define a forma como circular
        color: Colors.blue, // Cor de fundo do container
      ),
      child: Center(
        child: Text(
          'Texto Centralizado',
          style: TextStyle(
            color: Colors.white, // Cor do texto
            fontSize: 20.0, // Tamanho do texto
          ),
        ),
      ),
    );
  }
}

class CircularIconButtonProductOUT extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.pushNamed(context, '/pagina_destino02');

        print('Botão 02 pressionado');
      },
      child: CircleAvatar(
        radius: 30.0, // Tamanho do botão circular
        backgroundColor: Colors.blue, // Cor de fundo do botão
        child: Icon(
          Icons
              .add_shopping_cart, // Ícone do botão (substitua pelo ícone desejado)
          color: Colors.white, // Cor do ícone
          size: 40.0, // Tamanho do ícone
        ),
      ),
    );
  }
}

class CircularIconButtonProductIN extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.pushNamed(context, '/pagina_destino');

        print('Botão 01 pressionado');
      },
      child: CircleAvatar(
        radius: 30.0, // Tamanho do botão circular
        backgroundColor: Colors.blue, // Cor de fundo do botão
        child: Icon(
          Icons.add, // Ícone do botão (substitua pelo ícone desejado)
          color: Colors.white, // Cor do ícone
          size: 40.0, // Tamanho do ícone
        ),
      ),
    );
  }
}

class CircularIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;

  CircularIconButton({required this.icon, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPressed,
      child: CircleAvatar(
        backgroundColor: Colors.blue,
        child: Icon(
          icon,
          color: Colors.white,
        ),
      ),
    );
  }
}

class ProductListPage extends StatelessWidget {
  final List<Produto> products;

  ProductListPage({required this.products});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de Produtos'),
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(products[index].nome),
            subtitle: Text('Quantidade: ${products[index].quantidade}'),
          );
        },
      ),
    );
  }
}

class BarraDePesquisaWidget extends StatefulWidget {
  final Function(String)? onTextChanged;
  final VoidCallback? onSearchPressed;

  BarraDePesquisaWidget({
    this.onTextChanged,
    this.onSearchPressed,
  });
  // const BarraDePesquisaWidget({super.key});

  @override
  State<BarraDePesquisaWidget> createState() => _BarraDePesquisaWidgetState();
}

class _BarraDePesquisaWidgetState extends State<BarraDePesquisaWidget> {
  List<dynamic> produtos = [];
  final controlerPesquisar = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final productsProvider = context.watch<ProductProvider>();

    return Container(
      padding: EdgeInsets.only(left: 10, right: 10),
      margin: EdgeInsets.only(left: 40, right: 40),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.grey), // Borda para o Container
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: controlerPesquisar,
              decoration: InputDecoration(
                hintText: "Pesquisar",
                border: InputBorder.none,
              ),
              onChanged: (value) async {
                final resultados = await productsProvider.buscarProdutos(value);
                print("Resultado: $resultados");
              },
            ),
          ),
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              // onSearchPressed?.call();
            },
          ),
        ],
      ),
    );
  }
}


class PesquisaTeste extends StatefulWidget {
  final Function(String)? onTextChanged;
  final VoidCallback? onSearchPressed;

  PesquisaTeste({
    this.onTextChanged,
    this.onSearchPressed,
  });
  // const BarraDePesquisaWidget({super.key});

  @override
  State<PesquisaTeste> createState() => _PesquisaTesteState();
}

class _PesquisaTesteState extends State<PesquisaTeste> {
  List<dynamic> produtos = [];
  final controlerPesquisar = TextEditingController();
   static const double maxHeight = 250.0;
            static const double itemHeight = 50.0;

  @override
  Widget build(BuildContext context) {
    final productsProvider = context.watch<ProductProvider>();

  return Container(
    padding: EdgeInsets.symmetric(horizontal: 40),
    child: Column(
      children: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: Colors.grey),
          ),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controlerPesquisar,
                  decoration: InputDecoration(
                    hintText: "Pesquisar",
                    border: InputBorder.none,
                  ),
                  onChanged: (value) async {
                    final resultados =
                        await productsProvider.buscarProdutos(value);
                    print("Resultado: $resultados");

                    setState(() {
                      produtos = resultados;
                    });
                  },
                ),
              ),
              IconButton(
                icon: Icon(Icons.search),
                onPressed: () {
                  // onSearchPressed?.call();
                },
              ),
            ],
          ),
        ),
        SizedBox(height: 10),
        if (controlerPesquisar.text.isNotEmpty && produtos.isNotEmpty)
          ConstrainedBox(
            
            constraints: BoxConstraints(
            
              minHeight: 50,
              maxHeight: math.min(50 * produtos.length.toDouble(), 200), // ajustando a altura para corresponder ao número de produtos
            ),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: Color.fromARGB(255, 255, 254, 254),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: ListView.builder(
                itemCount: produtos.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(produtos[index]['nome']),
                    onTap: () {},
                  );
                },
              ),
            ),
          ),
      ],
    ),
  );


  }
}

class PesquisaComIconeWidget extends StatelessWidget {
  final TextEditingController? controller;
  final Function(String)? onTextChanged;
  final VoidCallback? onSearchPressed;

  PesquisaComIconeWidget({
    this.controller,
    this.onTextChanged,
    this.onSearchPressed,
  });

  @override
  Widget build(BuildContext context) {
    final productsProvider = context.watch<ProductProvider>();
    List<Produto> produtos = [];

    return Container(
      padding: EdgeInsets.only(left: 10, right: 10),
      margin: EdgeInsets.only(left: 40, right: 40),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.grey), // Borda para o Container
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: controller,
              decoration: InputDecoration(
                hintText: "Pesquisar",
                border: InputBorder.none,
              ),
              onChanged: (value) async {
                final resultados = await productsProvider.buscarProdutos(value);
                // setState( () {
                //   produtos = resultados;
                // });
              },
            ),
          ),
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              onSearchPressed?.call();
            },
          ),
        ],
      ),
    );
  }
}

class PesquisaComIconeScreen extends StatefulWidget {
  @override
  _PesquisaComIconeScreenState createState() => _PesquisaComIconeScreenState();
}

class _PesquisaComIconeScreenState extends State<PesquisaComIconeScreen> {
  TextEditingController? searchController;
  String searchText = "";

  void handleSearchTextChange(String value) {
    setState(() {
      searchText = value;
    });
  }

  void handleSearchPressed() {
    // Implemente a ação de pesquisa aqui
    print("Pesquisar: $searchText");
  }

  @override
  void initState() {
    super.initState();
    searchController = TextEditingController();
  }

  @override
  void dispose() {
    searchController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            PesquisaComIconeWidget(
              controller: searchController,
              onTextChanged: handleSearchTextChange,
              onSearchPressed: handleSearchPressed,
            ),
            SizedBox(height: 16.0),
            Text("Resultado da Pesquisa: $searchText"),
          ],
        ),
      ),
    );
  }
}
