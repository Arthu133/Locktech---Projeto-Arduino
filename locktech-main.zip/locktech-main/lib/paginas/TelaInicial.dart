import 'dart:async';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:locktech/entidades/entidades.dart';
import 'package:locktech/main.dart';
import 'package:locktech/paginas/produto_api.dart';
import 'package:locktech/provider/provider.dart';

final String azul = "#140FF0";
Color corAzulPadrao =
    Color(int.parse(azul.substring(1, 7), radix: 16) + 0xFF000000);
final String branco = "#FFFFFF";
Color corBrancaPadrao =
    Color(int.parse(branco.substring(1, 7), radix: 16) + 0xFF000000);

final String verdeAgua = "#0064C2";
Color corVerdeAgua =
    Color(int.parse(verdeAgua.substring(1, 7), radix: 16) + 0xFF000000);

final String roxo = "#004F99";
Color corRoxo =
    Color(int.parse(roxo.substring(1, 7), radix: 16) + 0xFF000000);

final String azulClaro = "#0078E5";
Color corAzulClaro =
    Color(int.parse(azulClaro.substring(1, 7), radix: 16) + 0xFF000000);


final String amarelo = "#0C0B47";
Color corAmarelo =
    Color(int.parse(amarelo.substring(1, 7), radix: 16) + 0xFF000000);


class TelaInicial extends StatefulWidget {
  const TelaInicial({super.key});

  @override
  State<TelaInicial> createState() => _TelaInicialState();
}

class _TelaInicialState extends State<TelaInicial> with ChangeNotifier {
  Timer? _timerProdutos;
  Timer? _timerLivros;
  Timer? _timerRoupas;
  Timer? _timerAlimentos;

  List<String> nomeCategoria = ["Livros", "Roupas", "Alimentos"];
  List<Produto> listaDeProdutos = [];
  List<Produto> listaCategoriaLivros = [];
  List<Produto> listaCategoriaRoupas = [];
  List<Produto> listaCategoriaAlimentos = [];

  List<Produto> get _listaDeProdutos => _listaDeProdutos;
  List<Produto> get _listaCategoriaLivros => _listaCategoriaLivros;
  List<Produto> get _listaCategoriaRoupas => _listaCategoriaRoupas;
  List<Produto> get _listaCategoriaAlimentos => _listaCategoriaAlimentos;

  String graficoLabel = 'Descricao dos produtos';

  void _startPollingProdutos() {
    _timerProdutos = Timer.periodic(Duration(seconds: 10), (timer) {
      ProdutoApi fetcher = ProdutoApi(
        apiUrl: "http://192.168.122.1:8082/api/listar2",
        onProdutoFetched: atualizarProdutos,
      );
      fetcher.fetchData();
    });
  }

  void _startPollingLivros() {
    _timerProdutos = Timer.periodic(Duration(seconds: 10), (timer) {
      ProdutoApi livrosAPI = ProdutoApi(
        apiUrl: "http://192.168.122.1:8082/api/filterCategoria/Livros",
        onProdutoFetched: getLivros,
      );
      livrosAPI.fetchData();
    });
  }

    void _startPollingAlimentos() {
    _timerProdutos = Timer.periodic(Duration(seconds: 10), (timer) {
      ProdutoApi alimentosAPI = ProdutoApi(
        apiUrl: "http://192.168.122.1:8082/api/filterCategoria/Alimentos",
        onProdutoFetched: getAlimentos,
      );
      alimentosAPI.fetchData();
    });
  }


    void _startPollingRoupas() {
    _timerProdutos = Timer.periodic(Duration(seconds: 10), (timer) {
      ProdutoApi roupasAPI = ProdutoApi(
        apiUrl: "http://192.168.122.1:8082/api/filterCategoria/Roupas",
        onProdutoFetched: getRoupas,
      );
      roupasAPI.fetchData();
    });
  }

  

  void atualizarProdutos(List<Produto> produtos) {
    setState(() {
      listaDeProdutos = produtos;
    });
  }

  void getLivros(List<Produto> produtos) {
    setState(() {
      listaCategoriaLivros = produtos;
    });
  }

  void getRoupas(List<Produto> produtos) {
    setState(() {
      listaCategoriaRoupas = produtos;
    });
  }

  void getAlimentos(List<Produto> produtos) {
    setState(() {
      listaCategoriaAlimentos = produtos;
    });
  }

  void initState() {
    super.initState();

    _startPollingLivros();
    _startPollingAlimentos();
    _startPollingRoupas();

    ProdutoApi fetcher = ProdutoApi(
      apiUrl: "http://192.168.122.1:8082/api/listar2",
      onProdutoFetched: atualizarProdutos,
      
    );

    ProdutoApi livrosAPI = ProdutoApi(
      apiUrl: "http://192.168.122.1:8082/api/filterCategoria/Livros",
      onProdutoFetched: getLivros,
    );

    ProdutoApi roupasAPI = ProdutoApi(
      apiUrl: "http://192.168.122.1:8082/api/filterCategoria/Roupas",
      onProdutoFetched: getRoupas,
    );

    ProdutoApi alimentosAPI = ProdutoApi(
      apiUrl: "http://192.168.122.1:8082/api/filterCategoria/Alimentos",
      onProdutoFetched: getAlimentos,
    );

    fetcher.fetchData();
    livrosAPI.fetchData();
    roupasAPI.fetchData();
    alimentosAPI.fetchData();
    notifyListeners();
    
  }

  @override
  void dispose() {
    _timerAlimentos?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: ClipRRect(
        borderRadius: BorderRadius.vertical(
            top: Radius.circular(16.0), bottom: Radius.circular(0.0)),
        child: BottomAppBar(
          elevation: 5,
          height: 30,
          color: corAzulPadrao,
          child: Row(
            children: [
              Spacer(),
              Text("LockTech - Copyright 2023",
                  style: TextStyle(
                      color: corBrancaPadrao, fontWeight: FontWeight.bold)),
              Spacer(),
            ],
          ),
        ),
      ),
      appBar: AppBar(
        backgroundColor: corAzulPadrao,
        title: Text("LockTech"),
        centerTitle: true,
        leading: Icon(
          Icons.menu,
          color: corBrancaPadrao,
        ),
        actions: [
          IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.notifications,
                color: corBrancaPadrao,
              ))
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SmallSpaceContainer(),
            Container(
              height: 200,
              child: loadGrafico(),
            ),
            SmallSpaceContainer(),
            Container(
              padding: EdgeInsets.all(8),
              margin: EdgeInsets.only(left: 18,right: 18),
              decoration: 
              BoxDecoration(
                color: corAzulPadrao,
                borderRadius: BorderRadius.circular(20),
              ),
              height: 40,
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.stop,
                          color: Colors.red,
                          size: 24,
                        ),
                        Text(
                          'Roupas',
                          style: TextStyle(color: corBrancaPadrao),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.stop,
                          color: Color.fromARGB(255, 133, 193, 250),
                          size: 24,
                        ),
                        Text('Alimentos',
                            style: TextStyle(color: corBrancaPadrao)),
                      ],
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.stop,
                          color: Color.fromARGB(255, 5, 247, 5),
                          size: 24,
                        ),
                        Text('Eletronico',
                            style: TextStyle(color: corBrancaPadrao)),
                      ],
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.stop,
                          color: Color.fromARGB(255, 226, 241, 4),
                          size: 24,
                        ),
                        Text('Livros',
                            style: TextStyle(color: corBrancaPadrao)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SmallSpaceContainer(),
            BotoesPrincipaisAplicacao(),
            MediumSpaceContainer(),
          ],
        ),
      ),
    );
  }

  loadGrafico() {
    return (listaDeProdutos.length.toDouble() <= 0 || listaDeProdutos.length == null)
        ? Container(
            width: MediaQuery.of(context).size.width,
            height: 200,
            child: Center(
              child: Column(

                children: [
                  Text("Carregando informacoes..."),
                  SmallSpaceContainer(),
                  CircularProgressIndicator(
      
              ),
                ],
              )
            ),
          )
        : Stack(
            alignment: Alignment.center,
            children: [
              Text("Estoque"),
              AspectRatio(
                aspectRatio: 1,
                child: PieChart(
                    swapAnimationDuration: const Duration(milliseconds: 750),
                    PieChartData(sections: [
                      PieChartSectionData(
                        // title: 'Alimentos',

                        value: listaCategoriaAlimentos.length.toDouble(),
                        color: corVerdeAgua,
                        //  Colors.red,
                      ),
                      PieChartSectionData(
                        // title: 'Livros',
                        value: listaCategoriaLivros.length.toDouble(),
                        color: corRoxo
                        //  Color.fromARGB(255, 133, 193, 250),
                      ),
                      PieChartSectionData(
                        // title: 'Roupas',
                        value: listaCategoriaRoupas.length.toDouble(),
                        color:corAzulClaro
                        //  Color.fromARGB(255, 10, 221, 73),
                      ),
                      PieChartSectionData(
                        value: 16,
                        color: corAmarelo,
                        // Color.fromARGB(255, 228, 175, 4),
                      ),
                    ])),
              ),
            ],
          );
  }
}

class BotoesPrincipaisAplicacao extends StatelessWidget {
  const BotoesPrincipaisAplicacao({super.key});

  @override

  Widget build(BuildContext context) {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            children: [
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: corAzulPadrao),
                height: 50,
                width: 50,
                child: IconButton(
                  icon: Icon(
                    Icons.add,
                    color: corBrancaPadrao,
                  ),
                  onPressed: () {
                    Navigator.pushNamed(context, "/pagina_destino");
                  },
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Text(
                'Adicionar Produto',
                style: TextStyle(
                    fontSize: 11,
                    color: corAzulPadrao,
                    fontWeight: FontWeight.bold),
              ),

              SmallSpaceContainer(),
              // Novo Coluna insirar os dados aqui

              Row(
                children: [
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: corAzulPadrao),
                        height: 50,
                        width: 50,
                        child: IconButton(
                          icon: Icon(
                            Icons.get_app,
                            color: corBrancaPadrao,
                          ),
                          onPressed: () {
                            Navigator.pushNamed(context, "/pagina_destino02");
                          },
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        'Retirar Produto',
                        style: TextStyle(
                            fontSize: 11,
                            color: corAzulPadrao,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ],
              )
            ],
          ),
          SmallSpaceContainer(),

          Column(
            children: [
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: corAzulPadrao),
                height: 50,
                width: 50,
                child: IconButton(
                  icon: Icon(
                    Icons.add,
                    color: corBrancaPadrao,
                  ),
                  onPressed: () {
                    Navigator.pushNamed(context, "/carrinho_compra");
                    
                  },
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Text(
                //'Categoria Produtos',
                "Close ESP 32",
                style: TextStyle(
                    fontSize: 11,
                    color: corAzulPadrao,
                    fontWeight: FontWeight.bold),
              ),


              SmallSpaceContainer(),

              // Novo Coluna insirar os dados aqui

              Row(
                children: [
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: corAzulPadrao),
                        height: 50,
                        width: 50,
                        child: IconButton(
                          icon: Icon(
                            Icons.add,
                            color: corBrancaPadrao,
                          ),
                          onPressed: () {
                            Navigator.pushNamed(context, "/carrinho_compra");
                          },
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        'Abrir ESP 32',
                        style: TextStyle(
                            fontSize: 11,
                            color: corAzulPadrao,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ],
              )
            ],
          ),
          

          
        ],
      ),
    );
  }
}


            // Container(
            //   height: 300,
            //   child: ListView.builder(
            //       itemCount: listaDeProdutos.length,
            //       itemBuilder: (BuildContext context, int index) {
            //         return ListTile(
            //           title: Text(listaDeProdutos[index].nome),
            //           subtitle: Text(listaDeProdutos[index].descricao),
            //         );
            //       }),
            // )