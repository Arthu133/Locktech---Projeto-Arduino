
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:locktech/entidades/entidades.dart';
import 'package:locktech/paginas/TelaInicial.dart';
import 'package:locktech/paginas/adicionar_produto.dart';
import 'package:locktech/main.dart';



class PaginaDestino02 extends StatefulWidget {
  const PaginaDestino02({super.key});

  @override
  State<PaginaDestino02> createState() => _PaginaDestino02State();
}

class _PaginaDestino02State extends State<PaginaDestino02> {
  final String apiUrl = 'http://192.168.122.1:8082/api/listar2';
  List<Produto> listaDeProdutos = [];

  @override
  void initState() {
    super.initState();
  }

  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      bottomNavigationBar: ClipRRect(
        borderRadius: BorderRadius.vertical(
            top: Radius.circular(16.0), bottom: Radius.circular(0.0)),
        child: BottomAppBar(
          elevation: 5,
          height: 30,
          color: corAzulPadrao,
          child: Row(
            children: [
              Spacer(),
              Text("LockTech - Copyright 2023",
                  style: TextStyle(
                      color: corBrancaPadrao, fontWeight: FontWeight.bold)),
              Spacer(),
            ],
          ),
        ),
      ),

      appBar: AppBar(
        backgroundColor: corAzulPadrao,
        title: Text('LochTech'),
       actions: [
          IconButton(onPressed: () {
            Navigator.pushNamed(context, "/carrinho_compra");
          }, icon: Icon(Icons.shopping_cart_sharp))
        ],
        centerTitle: true,
      ),
      body: ListView(
        children: [
          SmallSpaceContainer(),

          CabecalhoAdicionarProduto(iconeCabecalho: Icons.get_app, nomeCabecalho: "Retirar produto",),
          TinySpaceContainer(),
          // MediumSpaceContainer(),
          PesquisaTeste(),
          // BarraDePesquisaWidget(),
          // PesquisaComIconeWidget(),

          SmallSpaceContainer(),
          Center(
            child: Text("Categorias",style: TextStyle(fontSize: 21),),
          ),
          TinySpaceContainer(), 
        
         BotoesCategoriaRetirarProduto(),

         TinySpaceContainer(),


          // Column(
          //   children: listaDeProdutos.map((product) {
          //     return ListTile(
          //       title: Text(product.nome),
          //       subtitle: Text('Quantidade: ${product.quantidade}'),
          //       trailing: ElevatedButton(
          //         onPressed: () {
          //           print('Botão de adicionar ao carinho');
          //         },
          //         child: Text('ADD'),
          //       ),
          //     );
          //   }).toList(),
          // ),




        ],
      ),
    );
  }
}




class BotoesCategoriaRetirarProduto extends StatelessWidget {
  const BotoesCategoriaRetirarProduto({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            children: [
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: corAzulPadrao),
                height: 50,
                width: 50,
                child: IconButton(
                  icon: Icon(
                    Icons.import_contacts,
                    color: corBrancaPadrao,
                  ),
                  onPressed: () {
                    Navigator.pushNamed(context, "/categoria_produto", arguments: "Livros");
                  },
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Text(
                'Livros',
                style: TextStyle(
                    fontSize: 11,
                    color: corAzulPadrao,
                    fontWeight: FontWeight.bold),
              ),

              SmallSpaceContainer(),
              // Novo Coluna insirar os dados aqui

              Row(
                children: [
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: corAzulPadrao),
                        height: 50,
                        width: 50,
                        child: IconButton(
                          icon: Icon(
                            Icons.local_pizza_sharp,
                            color: corBrancaPadrao,
                          ),
                          onPressed: () {
                            Navigator.pushNamed(context, "/categoria_produto", arguments: "Alimentos");
                          },
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        'Alimentos',
                        style: TextStyle(
                            fontSize: 11,
                            color: corAzulPadrao,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ],
              )
            ],
          ),
          SmallSpaceContainer(),

          Column(
            children: [
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: corAzulPadrao),
                height: 50,
                width: 50,
                child: IconButton(
                  icon: Icon(
                    Icons.laptop_chromebook,
                    color: corBrancaPadrao,
                  ),
                  onPressed: () {
                    Navigator.pushNamed(context, "/pagina_destino");
                  },
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Text(
                'Eletronicos',
                style: TextStyle(
                    fontSize: 11,
                    color: corAzulPadrao,
                    fontWeight: FontWeight.bold),
              ),


              SmallSpaceContainer(),

              // Novo Coluna insirar os dados aqui

              Row(
                children: [
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: corAzulPadrao),
                        height: 50,
                        width: 50,
                        child: IconButton(
                          icon: Icon(
                            Icons.checkroom,
                            color: corBrancaPadrao,
                          ),
                          onPressed: () {
                            Navigator.pushNamed(context, "/categoria_produto", arguments: "Roupas");
                          },
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        'Roupas',
                        style: TextStyle(
                            fontSize: 11,
                            color: corAzulPadrao,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ],
              )
            ],
          ),
          

          
        ],
      ),
    );
  }
}

