import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:locktech/entidades/entidades.dart';
import 'package:locktech/paginas/TelaInicial.dart';
import 'package:locktech/paginas/adicionar_produto.dart';
import 'package:locktech/paginas/carrinho_compra.dart';
import 'package:locktech/paginas/categoria_produto.dart';
import 'package:locktech/paginas/detalhe_produto.dart';
import 'package:locktech/paginas/pesquisar_teste.dart';
import 'package:locktech/paginas/retirar_produto.dart';
import 'package:locktech/paginas/stream_teste.dart';
import 'package:locktech/provider/provider.dart';
import 'package:provider/provider.dart';

class TelaBuscaProdutos extends StatefulWidget {

  @override
  _TelaBuscaProdutosState createState() => _TelaBuscaProdutosState();
}

class _TelaBuscaProdutosState extends State<TelaBuscaProdutos> {
    final controlerPesquisar = TextEditingController();
    List<dynamic> produtos = [];


  @override
  Widget build(BuildContext context) {
    final productsProvider = context.watch<ProductProvider>();

    return Scaffold(
      appBar: AppBar(title: Text('Busca de Produtos')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: controlerPesquisar,
              onChanged: (value) async {
                final resultados = await productsProvider.buscarProdutos(value);
                print(resultados);
                setState(() {
                  produtos = resultados;
                });
              },
              decoration: InputDecoration(labelText: 'Pesquisar...'),
            ),
          ),
         Expanded(
  child:
    ListView.builder(
        itemCount: produtos.length,
        itemBuilder: (context, index) {
          return  Text(produtos[index]['nome']);
        },
      )
)
        ],
      ),
    );
  }
}
