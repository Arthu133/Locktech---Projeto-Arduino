import 'package:flutter/material.dart';
import 'package:locktech/BLoC/contador_detalhe_produto.dart';
import 'package:locktech/entidades/entidades.dart';
import 'package:locktech/main.dart';
import 'package:locktech/paginas/TelaInicial.dart';
import 'package:locktech/provider/provider.dart';
import 'package:provider/provider.dart';

class DetalheProdutoPage extends StatefulWidget {
  final Produto produtos;
  const DetalheProdutoPage({super.key, required this.produtos});

  @override
  State<DetalheProdutoPage> createState() => _DetalheProdutoPageState();
}

class _DetalheProdutoPageState extends State<DetalheProdutoPage> {
  final _bloc = CounterBloc();
  final _blocTamanho = SizeBloc();

  void addCart(Produto produtoUnidade) {
    Provider.of<ProductProvider>(context, listen: false).addItemCart(produtoUnidade);
  }
  

  @override
  void initState() {
    super.initState();

    // Aqui, você pode usar widget.categoria para acessar o valor
    print(widget.produtos);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: ClipRRect(
          borderRadius: BorderRadius.vertical(
              top: Radius.circular(16.0), bottom: Radius.circular(0.0)),
          child: BottomAppBar(
            elevation: 5,
            height: 30,
            color: corAzulPadrao,
            child: Row(
              children: [
                Spacer(),
                Text("LockTech - Copyright 2023",
                    style: TextStyle(
                        color: corBrancaPadrao, fontWeight: FontWeight.bold)),
                Spacer(),
              ],
            ),
          ),
        ),
        appBar: AppBar(
          backgroundColor: corAzulPadrao,
          title: Text('LochTech'),
         actions: [
          IconButton(onPressed: () {
            Navigator.pushNamed(context, "/carrinho_compra");
          }, icon: Icon(Icons.shopping_cart_sharp))
        ],
          centerTitle: true,
        ),
        body: ListView(
          children: [
            Container(
              margin: EdgeInsets.only(top: 50),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Center(
                      child: Text(
                    "Detalhe: ${widget.produtos.nome}",
                    style: TextStyle(fontSize: 18),
                  )),
                  SmallSpaceContainer(),
                ],
              ),
            ),
            Container(
              decoration: BoxDecoration(
                  color: corAzulPadrao,
                  borderRadius: BorderRadius.circular(55)),
              height: 350,
              margin: EdgeInsets.only(left: 10, right: 10),
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 10),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(55)),
                    height: 80,
                    width: 80,
                    child: Icon(
                      Icons.local_activity_rounded,
                      color: corAzulPadrao,
                      size: 40,
                    ),
                  ),
                  TinySpaceContainer(),
                  Text(
                    "Quantidade:",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  TinySpaceContainer(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                          onPressed: () {
                            _bloc.counterEventSink.add(CounterEvent.decrement);
                          },
                          icon: Icon(
                            Icons.remove,
                            size: 30,
                            color: Colors.white,
                          )),
                      Container(
                        height: 40,
                        width: 30,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                        ),
                        child: Center(
                            child: StreamBuilder<int>(
                          stream: _bloc.counterStream,
                          initialData: 0,
                          builder: (context, snapshop) {
                            return Text(
                              "${snapshop.data}",
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold),
                            );
                          },
                        )),
                      ),
                      IconButton(
                          onPressed: () {
                            _bloc.counterEventSink.add(CounterEvent.increment);
                          },
                          icon: Icon(
                            Icons.add,
                            size: 30,
                            color: Colors.white,
                          ))
                    ],
                  ),
                  TinySpaceContainer(),
                  Text(
                    "Tamanho:",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  TinySpaceContainer(),
                  StreamBuilder<ProductSize>(
                      stream: _blocTamanho.sizeStream,
                      initialData: ProductSize.none,
                      builder: (context, snapshot) {
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            opcaoTamanho("P", ProductSize.small, snapshot.data),
                            opcaoTamanho(
                                "M", ProductSize.medium, snapshot.data),
                            opcaoTamanho("G", ProductSize.large, snapshot.data),
                          ],
                        );
                      })
                ],
              ),
            ),
            TinySpaceContainer(),
            Container(
              padding: EdgeInsets.all(8),
              margin: EdgeInsets.only(left: 130, right: 130),
              decoration: BoxDecoration(
                  color: corAzulPadrao,
                  borderRadius: BorderRadius.circular(55)),
              height: 40,
              width: 10,
              child: TextButton(
                  onPressed: () {
                    addCart(widget.produtos);
                    print("Confirmado");
                    Navigator.pop(context);
                  },

                  child: Text(
                    "Confirmar",
                    style: TextStyle(color: Colors.white),
                  )),
            )
          ],
        ));
  }

  Widget opcaoTamanho(
      String label, ProductSize size, ProductSize? currentSize) {
    bool isSelected = size == currentSize;

    return GestureDetector(
      onTap: () {
        _blocTamanho.sizeEventSink.add(size);
      },
      child: Container(
        margin: EdgeInsets.only(right: 10),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(55),
            border: Border.all(
                color: isSelected ? Color.fromARGB(255, 230, 120, 18) : Color.fromARGB(0, 56, 206, 168), width: 5)),
        height: 40,
        width: 40,
        child: Center(
            child: Text(
          label,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        )),
      ),
    );
  }
}
