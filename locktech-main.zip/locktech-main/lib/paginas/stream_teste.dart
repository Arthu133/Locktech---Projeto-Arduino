import 'package:flutter/material.dart';
import 'package:locktech/BLoC/contador_detalhe_produto.dart';


class SizeSelectorPage extends StatefulWidget {
  @override
  _SizeSelectorPageState createState() => _SizeSelectorPageState();
}

class _SizeSelectorPageState extends State<SizeSelectorPage> {
  final _bloc = SizeBloc();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Select Product Size')),
      body: Center(
        child: StreamBuilder<ProductSize>(
          stream: _bloc.sizeStream,
          initialData: ProductSize.none,
          builder: (context, snapshot) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildSizeOption('Small', ProductSize.small, snapshot.data),
                _buildSizeOption('Medium', ProductSize.medium, snapshot.data),
                _buildSizeOption('Large', ProductSize.large, snapshot.data),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildSizeOption(String label, ProductSize size, ProductSize? currentSize) {
    return ListTile(
      title: Text(label),
      leading: Radio<ProductSize>(
        value: size,
        groupValue: currentSize,
        onChanged: (selectedSize) {
          _bloc.sizeEventSink.add(selectedSize!);
        },
      ),
    );
  }

  @override
  void dispose() {
    _bloc.dispose();
    super.dispose();
  }
}
