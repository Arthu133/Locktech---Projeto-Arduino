import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:locktech/paginas/TelaInicial.dart';
import 'package:locktech/entidades/entidades.dart';
import 'package:locktech/main.dart';
import 'package:http/http.dart' as http;
import 'package:locktech/paginas/produto_api.dart';

class PaginaAdicionarProduto extends StatelessWidget {
  //const PaginaDestino({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: corAzulPadrao,
        title: Text('LochTech'),
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.notifications))
        ],
        centerTitle: true,
      ),
      body: ListView(
        children: [
          SmallSpaceContainer(),
          CabecalhoAdicionarProduto( iconeCabecalho: Icons.add , nomeCabecalho: "Formulario Produto"),
          SmallSpaceContainer(),
          ProductInput(),
          MediumSpaceContainer(),
        ],
      ),
    );
  }
}

class CabecalhoAdicionarProduto extends StatelessWidget {
  late final IconData iconeCabecalho;
  late final String nomeCabecalho;

  CabecalhoAdicionarProduto({required this.iconeCabecalho, required this.nomeCabecalho, });
  
  //const LogoCircular({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        height: 120,
        width: 150,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: corAzulPadrao,
        ),
        child: Container(
          padding: EdgeInsets.only(top: 30),
          child: Column(
            children: [
              Container(
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: corBrancaPadrao),
                  child: IconButton(
                      onPressed: null,
                      icon: Icon(iconeCabecalho, color: corAzulPadrao))),
              SizedBox(
                height: 10,
              ),
              Text(
                nomeCabecalho,
                style: TextStyle(
                    fontSize: 11,
                    color: corBrancaPadrao,
                    fontWeight: FontWeight.bold),
              )
            ],
          ),
        ),
      ),
    );
  }
}

Widget espacoEntreCamposFormulario() {
  return SizedBox(
    height: 5,
  );
}

class ProductInput extends StatefulWidget {
  @override
  _ProductInputState createState() => _ProductInputState();
}

class _ProductInputState extends State<ProductInput> {
  final String apiUrl =
      'http://192.168.122.1:8082/api'; // Substitua pela URL correta
  TextEditingController _nomeController = TextEditingController();
  TextEditingController _quantidadeController = TextEditingController();
  TextEditingController _imagemController = TextEditingController();
  TextEditingController _descricaoController = TextEditingController();
  TextEditingController _categoriaController = TextEditingController();
  TextEditingController _EletronicosController = TextEditingController();
  TextEditingController _quantidadeInicialController = TextEditingController();
  TextEditingController _dataValidadeController = TextEditingController();
  // TextEditingController _fracaoUtiizacaoController = TextEditingController();
  TextEditingController _dataDeRegistroController = TextEditingController();

  late ProdutoApi apiControl;
  List<dynamic> listaprodutos = [];
  // final Function(List<Produto>) onProdutoFetched = [];

  void getProdutos(List<Produto> produtos) {
    setState(() {
      listaprodutos = produtos;
    });
  }

  void initState() {
    apiControl = new ProdutoApi(apiUrl: apiUrl, onProdutoFetched: getProdutos);
  }

  final _formKey = GlobalKey<FormState>();

  // @override
  // void dispose() {
  //   _nomeController.dispose();
  //   _quantidadeController.dispose();
  //   _imagemController.dispose();
  //   _descricaoController.dispose();
  //   _categoriaController.dispose();
  //   _quantidadeInicialController.dispose();
  //   _dataValidadeController.dispose();
  //   _dataDeRegistroController.dispose();
  //   super.dispose();
  // }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Processando...')),
      );
    }

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Form(
        key: _formKey,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            espacoEntreCamposFormulario(),
            Container(
              height: 50,
              width: 300,
              child: TextFormField(
                style: TextStyle(fontSize: 11),
                controller: _imagemController,
                decoration: InputDecoration(
                  hintText: 'Imagem:',
                  hintStyle: TextStyle(fontSize: 11),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Campo obrigatorio!';
                  }
                  return null;
                },
              ),
            ),
            espacoEntreCamposFormulario(),
            Container(
              height: 50,
              width: 300,
              child: TextFormField(
                style: TextStyle(fontSize: 11),
                controller: _nomeController,
                decoration: InputDecoration(
                  hintText: 'Nome:',
                  hintStyle: TextStyle(fontSize: 11),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Campo obrigatorio!';
                  }
                  return null;
                },
              ),
            ),
            espacoEntreCamposFormulario(),
            Container(
              height: 50,
              width: 300,
              child: TextFormField(
                style: TextStyle(fontSize: 11),
                controller: _descricaoController,
                decoration: InputDecoration(
                  hintText: 'Descricao:',
                  hintStyle: TextStyle(fontSize: 11),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Campo obrigatorio!';
                  }
                  return null;
                },
              ),
            ),
            espacoEntreCamposFormulario(),
            Container(
              height: 50,
              width: 300,
              child: TextFormField(
                style: TextStyle(fontSize: 11),
                controller: _categoriaController,
                decoration: InputDecoration(
                  hintText: 'Categoria:',
                  hintStyle: TextStyle(fontSize: 11),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Campo obrigatorio!';
                  }
                  return null;
                },
              ),
            ),
            espacoEntreCamposFormulario(),
            Container(
              height: 50,
              width: 300,
              child: TextFormField(
                style: TextStyle(fontSize: 11),
                controller: _quantidadeInicialController,
                decoration: InputDecoration(
                  hintText: 'Quantidade Inicial:',
                  hintStyle: TextStyle(fontSize: 11),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Campo obrigatorio!';
                  }
                  return null;
                },
              ),
            ),
            espacoEntreCamposFormulario(),
            Container(
              height: 50,
              width: 300,
              child: TextFormField(
                style: TextStyle(fontSize: 11),
                controller: _quantidadeController,
                decoration: InputDecoration(
                  hintText: 'Quantidade:',
                  hintStyle: TextStyle(fontSize: 11),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Campo obrigatorio!';
                  }
                  return null;
                },
              ),
            ),
            espacoEntreCamposFormulario(),
            Container(
              height: 50,
              width: 300,
              child: TextFormField(
                style: TextStyle(fontSize: 11),
                controller: _dataValidadeController,
                decoration: InputDecoration(
                  hintText: 'Data de validade:',
                  hintStyle: TextStyle(fontSize: 11),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Campo obrigatorio!';
                  }
                  return null;
                },
              ),
            ),
            Container(
              height: 10,
            ),
            ElevatedButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(corAzulPadrao),
                foregroundColor: MaterialStateProperty.all(corBrancaPadrao),
              ),
              onPressed: () async {
                try {
                  var cadastroProduto = Produto(
                    id: 5,
                    imagem: _imagemController.text,
                    nome: _nomeController.text,
                    quantidade: int.parse(_quantidadeController.text),
                    descricao: _descricaoController.text,
                    categoria: _categoriaController.text,
                    quantidadeInicial: _quantidadeController.text,
                    dataValidade: _dataValidadeController.text,
                    dataDeRegistro: _dataDeRegistroController.text,
                  );

                  String resultado =
                      await apiControl.cadastrarProduto(cadastroProduto);

                  print('Produto cadastro com sucesso: $resultado');
                  _submitForm();
                  // final resultado = await cadastrarProduto();
                  // print('Produto cadastro com sucesso: $resultado');
                } catch (e) {
                  print('Erro ao cadastrar o produto: $e');
                }
                //_addProduct();
              },
              child: Text('Adicionar Produto'),
            ),
          ],
        ));
  }
}
