import 'package:flutter/material.dart';
import 'package:locktech/entidades/entidades.dart';
import 'package:locktech/main.dart';
import 'package:locktech/paginas/TelaInicial.dart';
import 'package:locktech/paginas/adicionar_produto.dart';
import 'package:locktech/provider/provider.dart';
import 'package:provider/provider.dart';

class CategoriaProdutoPage extends StatefulWidget {
  final String categoria;

  const CategoriaProdutoPage({super.key, required this.categoria});

  @override
  State<CategoriaProdutoPage> createState() => _CategoriaProdutoPageState();
}

class _CategoriaProdutoPageState extends State<CategoriaProdutoPage> {


  @override
  void initState() {
    super.initState();
   
    // Aqui, você pode usar widget.categoria para acessar o valor
    print(widget.categoria);
  }

  @override
  Widget build(BuildContext context) {

    final productsProvider = Provider.of<ProductProvider>(context);
    List<Produto> products;
    if(widget.categoria == "Livros") {
        products = productsProvider.listaCategoriaLivros;
    }else if(widget.categoria == "Alimentos"){
     products = productsProvider.listaCategoriaAlimentos;
    }else{
     products = productsProvider.listaCategoriaRoupas;
    }
    

    return Scaffold(
      bottomNavigationBar: ClipRRect(
        borderRadius: BorderRadius.vertical(
            top: Radius.circular(16.0), bottom: Radius.circular(0.0)),
        child: BottomAppBar(
          elevation: 5,
          height: 30,
          color: corAzulPadrao,
          child: Row(
            children: [
              Spacer(),
              Text("LockTech - Copyright 2023",
                  style: TextStyle(
                      color: corBrancaPadrao, fontWeight: FontWeight.bold)),
              Spacer(),
            ],
          ),
        ),
      ),
      appBar: AppBar(
        backgroundColor: corAzulPadrao,
        title: Text('LochTech'),
        actions: [
          IconButton(onPressed: () {
            Navigator.pushNamed(context, "/carrinho_compra");
          }, icon: Icon(Icons.shopping_cart_sharp))
        ],
        centerTitle: true,
      ),
      body: Column(
        children: [
          TinySpaceContainer(),
          CabecalhoAdicionarProduto(
            iconeCabecalho: Icons.import_contacts,
            nomeCabecalho: "Categoria: ${widget.categoria}",
          ),
          TinySpaceContainer(),
          Center(
            child: Text(
              " Selecione os produtos que deseja retirar",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),

          Text(products.length.toString()),

            Expanded(
              child:
              
            
          Consumer<ProductProvider>(
            builder: (context, provider, child)
            {
              
              if(products.isEmpty) {
                return Center(child: Text("Nenhum produto disponível"));
              }
              // return CardsProdutoCategoria();
               return ListView.builder(
                itemCount: products.length,
                itemBuilder: (context, index) {
                  return CardsProdutoCategoria(produtoCategoria: products[index],nome: products[index].nome, descricao: products[index].descricao);                  //Text(products[index].nome);
                },
              );
            },
          ),),
          // TinySpaceContainer(),
          // CardsProdutoCategoria(),
          // TinySpaceContainer(),
          // CardsProdutoCategoria(),
          // TinySpaceContainer(),
          // CardsProdutoCategoria(),
          // TinySpaceContainer(),
          // CardsProdutoCategoria(),
          // TinySpaceContainer(),
          // CardsProdutoCategoria(),
          // TinySpaceContainer(),
          // CardsProdutoCategoria(),
        ],
      ),
    );
  }
}

class CardsProdutoCategoria extends StatelessWidget {
  // const CardsProdutoCategoria({super.key});
  Produto produtoCategoria;
  String nome;
  String descricao;


  CardsProdutoCategoria({super.key ,required this.nome, required this.descricao, required this.produtoCategoria});

  @override
  Widget build(BuildContext context) {
    return Container(

      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20), // color: corAzulPadrao
        color: Colors.blueAccent.withOpacity(0.8),
      ),
      padding: EdgeInsets.all(8),
      margin: EdgeInsets.only(left: 15, right: 15,bottom: 10, top: 3),
      height: 60,
      width: 50,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CircleAvatar(backgroundColor: Colors.white),
          // Container Foto do Produto

          Expanded(
              child: Padding(
            padding: EdgeInsets.symmetric(vertical: 5.0, horizontal: 8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  nome,
                  style: TextStyle(fontSize: 14, color: Colors.white),
                ),
                SizedBox(
                  height: 5,
                ),
                Text(
                  descricao,
                  style: TextStyle(fontSize: 10, color: Colors.white),
                ),
              ],
            ),
          )),
          Container(
              decoration:
                  BoxDecoration(color: corAzulPadrao, shape: BoxShape.circle),
              child: IconButton(
                icon: Icon(
                  Icons.add,
                  color: Colors.white,
                ),
                onPressed: () {
                  //Produto( id: 5, nome: "Morfina", quantidade: 5, imagem: "morfina.png", descricao: "Morfina detalhes", categoria: "Livros", quantidadeInicial: "5", dataValidade: "2024-10-10", dataDeRegistro: "2023-14-10")
                  Navigator.pushNamed(context, "/detalhe_produto", arguments: produtoCategoria );
                  //_showMedicationDetails(context);
                  
                },
              )),
       

        ],
      ),
      
        
    );
         

  }
}



void _showMedicationDetails(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text("Morfina"),
        content: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,  // para evitar o diálogo se expandindo ao máximo
          children: [
            Text('Descrição: Morfina detalhes'),
            Text('Quantidade: 15'),
            Text('Tamanho: 15 cm'),
            // Adicione mais detalhes conforme necessário
          ],
        ),
        actions: <Widget>[
          TextButton(
            child: Text("Fechar"),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}

