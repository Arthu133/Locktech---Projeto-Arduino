import 'dart:convert';
import 'dart:ffi';

import 'package:locktech/entidades/entidades.dart';
import 'package:http/http.dart' as http;

class ProdutoApi {
  final String apiUrl;
  final Function(List<Produto>) onProdutoFetched;
  List<Produto> listaProdutos = [];

  ProdutoApi({required this.apiUrl, required this.onProdutoFetched});

  Future<void> fetchData() async {
    try {
      final response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        final List<dynamic> produtosJson = json.decode(response.body);
        final List<Produto> produtos =
            produtosJson.map((json) => Produto.fromJson(json)).toList();

        onProdutoFetched(produtos);
      } else {
        print('Erro na solicitação. Código de status: ${response.statusCode}');
      }
    } catch (e) {
      print('Erro durante a solicitação: $e');
    }
  }


  Future<void> getESP() async {
    try {
      final response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        final List<dynamic> produtosJson = json.decode(response.body);
        final List<Produto> produtos =
            produtosJson.map((json) => Produto.fromJson(json)).toList();

        onProdutoFetched(produtos);
      } else {
        print('Erro na solicitação. Código de status: ${response.statusCode}');
      }
    } catch (e) {
      print('Erro durante a solicitação: $e');
    }
  }

  Future<String> cadastrarProduto(Produto produto) async {
    try {
      
      var body = jsonEncode({
      'nome': produto.nome,
      'quantidade': produto.quantidade,
      'imagem': produto.imagem,
      'descricao': produto.descricao,
      'categoria': produto.categoria,
      'quantidadeInicial': produto.quantidadeInicial,
      'dataValidade': produto.dataValidade,
      'dataDeRegistro': produto.dataDeRegistro
      });

      final respostaServidor = await http.post(Uri.parse(apiUrl),
      
      body: body,
      headers: {
        'Content-Type': 'application/json',
      },);

      if(respostaServidor.statusCode == 200) {
        return "Produto cadastrado com sucesso!";

      }else {
        return 'Erro ao cadastrar produto: ${respostaServidor.body}';

      }

    }catch (e) {
      return 'Erro durante o cadastro de produto';
    }
  }




}

class CategoriaProdutoApi {
  final String apiUrl;
  final Function(List<Produto>) produtoCategoriaFetched;
  List<Produto> listaProdutos = [];

  CategoriaProdutoApi(
      {required this.apiUrl, required this.produtoCategoriaFetched});

  Future<List<Produto>> fetchProductsFromAPI() async {
    final response = await http.get(Uri.parse('YOUR_API_ENDPOINT_HERE'));

    if (response.statusCode == 200) {
      List<dynamic> jsonResponse = json.decode(response.body);
      return jsonResponse.map((data) => Produto.fromJson(data)).toList();
    } else {
      throw Exception('Failed to load products');
    }
  }

  Future<int> countProductsInCategory(String targetCategory) async {
  List<Produto> products = await fetchProductsFromAPI();
  return products.where((produto) => produto.categoria == targetCategory).length;
  
}
}
